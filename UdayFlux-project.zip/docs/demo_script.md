# 10-minute demonstration run sheet

## Working demo (8 minutes)

1. **Context and source (1 min):** Introduce the UCI single-household dataset, its 2006–2010 time range, sampling rate, units, and limits. Point to the downloaded source and project architecture diagram.
2. **Preparation and overview (1.5 min):** Open the data-quality expander; explain day-first parsing, missing `?` handling, limited interpolation and derived calendar fields. Show hourly load, daily shape, peak and selected date range.
3. **Anomalies (1.5 min):** Show the robust rolling median/MAD method, event table and one record's observed value, baseline, deviation and robust score. Explain that candidate events require review because there are no labeled anomalies.
4. **Forecast (1.5 min):** Show the next 24 hourly estimates and chronological holdout MAE/RMSE/MAPE alongside seasonal-naive baseline MAE. Explain the lag features and recursive forecast limit.
5. **Natural-language Q&A (1 min):** Ask “What was the peak demand?” and “Identify unusual consumption and supporting evidence.” Open the evidence payload and point out the query intent and provenance.
6. **LangGraph trace and decision support (1.5 min):** Ask “What operational insights can be derived?” Show the parallel Analysis, Anomaly and Forecast nodes joining at Insight, then the Decision Support node, with handoff IDs and evidence references. State clearly that observations alone do not establish why consumption changed.

## Q&A (2 minutes)

Be ready to explain: (a) why hourly means balance signal and runtime; (b) how the model is compared with a same-hour-previous-day baseline; (c) why anomaly precision/recall is absent without labels; (d) how the architecture could add regional, weather and generation feeds; (e) why recommendations are bounded to a single household rather than grid-control actions.
