# Design decisions and evaluation

## Dataset and preparation

The source is UCI's minute-resolution, 2,075,259-row, single-household dataset (Dec 2006-Nov 2010). Values are semicolon-separated; dates are day-first and missing numeric readings are marked `?`. Loading validates required columns, parses and sorts timestamps, removes invalid/duplicate timestamp rows, coerces numeric fields, interpolates gaps no longer than 60 minutes, and records before/after missing counts. Hour, weekday, month, weekend, and active energy per minute are derived. Mean active power (kW) is the dashboard load signal; submeter fields are retained for extension. Long missing runs remain missing and are excluded from hourly means.

## Analytics

Hourly means reduce noise and computation while preserving operational day shape. Peak is the maximum hourly mean. Seasonality is displayed by hour and weekday. Anomalies use a centered rolling median and rolling median absolute deviation, a robust score threshold of 4.5, and explicit value/baseline/deviation evidence. This is unsupervised: there are no truth labels in the dataset, therefore supervised effectiveness metrics would be misleading.

Forecasts use lags (1, 2, 3, 24, 25, 48, 168 hours), prior-day rolling mean and calendar covariates with a modest histogram gradient boosting regressor. A chronological final holdout prevents random leakage. MAE, RMSE and MAPE are reported alongside a previous-day seasonal-naive MAE. Forecasting falls back to a mean forecast for too-short windows. Long recursive horizons can accumulate error.

## Agent, LLM and query workflow

LangGraph `StateGraph` orchestrates five specialist roles. Data analysis, anomaly detection, and forecasting run as parallel graph nodes and join at the Energy Insight Agent; the graph then proceeds to Decision Support. Structured handoffs include evidence, sender/recipient roles, and message IDs. When configured, an OpenRouter LLM uses function calling to select deterministic local tools for summary, anomaly evidence, forecasts, or the LangGraph workflow, then writes the user-facing explanation from returned evidence. The default model is `openrouter/auto`, configurable with `OPENROUTER_MODEL`. A deterministic local query router remains the no-key/provider-failure fallback. The system prompt tells the model not to make causal claims from observational power readings. Prompt constraints do not guarantee perfect groundedness, so answers still need evaluation.

## Evaluation

Forecast metrics are calculated on a chronological holdout and compared to seasonal naive. Query quality can be assessed by whether selected tools match the request, whether the final answer agrees with tool outputs, and whether it handles unsupported requests correctly; generated answers should be reviewed against an annotated question set. The UI exposes tool names and returned evidence for this review. Anomaly candidates can be inspected and thresholded, but no precision/recall is reported without labels. Data correctness is made inspectable through quality counts, expected schema validation, date bounds, and units.

## Trade-offs and limits

This is a locally executable React/Vite frontend with a modular FastAPI backend, not a multi-container deployment. OpenRouter is optional; local analytics still work without an API credential. When enabled, user questions and selected tool evidence are sent to the configured OpenRouter model. Dataset geography and scope are one household, so regional grid, generation, weather, and equipment recommendations are outside the evidence available.
