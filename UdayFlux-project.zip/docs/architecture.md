# System architecture

```text
UCI TXT / local file
       ↓
Schema validation → timestamp and numeric cleaning → quality report + time features
       ↓
Hourly energy knowledge base
       ├── Trend / peak / seasonality analysis
       ├── Rolling median-MAD anomaly detector ──┐
       └── Forecast + chronological evaluation ──┤
                                                 ↓ evidence messages
                         LangGraph: Analysis / Anomaly / Forecast
                                                 ↓
                              Energy Insight Agent
                                                 ↓
                             Decision Support Agent
                                                 ↓
           FastAPI JSON API ← React/Vite analyst UI
                                                 ↓
                     Charts · agent studio · copilot · evidence
```

The React/Vite interface is served during development on port 5173 and calls the FastAPI service on port 8000. All analytics run locally. The dataset file remains local and the backend caches hourly aggregation to avoid repeated parsing. Agent communication is represented by structured messages with IDs and evidence references. With OpenRouter enabled, the question and selected computed evidence are sent to the configured model provider; the raw minute-level dataset stays local.
