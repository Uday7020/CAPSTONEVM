"""FastAPI service for the React energy intelligence dashboard."""
from datetime import date, datetime
from functools import lru_cache
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from energy_assistant.agents import EnergyAgentTeam
from energy_assistant.analytics import detect_anomalies, forecast, summarize
from energy_assistant.data import hourly_series, load_data
from energy_assistant.query import answer

app = FastAPI(title="UdayFlux Energy Intelligence API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["GET", "POST"], allow_headers=["Content-Type"])


@lru_cache(maxsize=1)
def _dataset():
    return load_data()


@lru_cache(maxsize=1)
def _all_hourly() -> pd.Series:
    frame, _ = _dataset()
    return hourly_series(frame)


def _window(days: int) -> pd.Series:
    series = _all_hourly()
    if days > 0:
        return series.loc[series.index >= series.index.max() - pd.Timedelta(days=days)]
    return series


def _clean(value):
    if isinstance(value, (pd.Timestamp, datetime, date)):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, np.generic):
        return value.item()
    if pd.isna(value) if not isinstance(value, (str, bytes, list, tuple, dict)) else False:
        return None
    return value


def _records(series: pd.Series, limit: int = 1100) -> list[dict]:
    stride = max(1, int(np.ceil(len(series) / limit)))
    sampled = series.iloc[::stride]
    return [{"time": timestamp.isoformat(), "value": round(float(value), 4)} for timestamp, value in sampled.items()]


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "energy-intelligence"}


@app.get("/api/dashboard")
def dashboard(days: int = Query(90, ge=7, le=1500)):
    try:
        series = _window(days)
        stats = summarize(series)
        all_anomalies = detect_anomalies(series)
        anomalies = all_anomalies.head(30).reset_index()
        anomalies = anomalies.rename(columns={anomalies.columns[0]: "timestamp"})
        future, metrics = forecast(series, 24)
        hourly = stats["hourly_mean_kw"]
        weekdays = stats["dow_mean_kw"]
        return _clean({
            "window": {"start": series.index.min(), "end": series.index.max(), "days": days},
            "metrics": {"mean_kw": stats["mean_kw"], "peak_kw": stats["max_kw"], "peak_time": stats["peak_time"], "anomaly_count": len(all_anomalies), "forecast_mean_kw": float(future.mean())},
            "demand": _records(series),
            "hourly_profile": [{"hour": int(h), "value": float(v)} for h, v in hourly.items()],
            "weekday_profile": [{"day": str(d), "value": float(v)} for d, v in weekdays.items()],
            "anomalies": anomalies.to_dict(orient="records"),
            "forecast": [{"time": t.isoformat(), "value": float(v)} for t, v in future.items()],
            "forecast_metrics": metrics,
            "data_quality": _dataset()[1],
        })
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/api/agents")
def agents(days: int = Query(90, ge=7, le=1500)):
    series = _window(days)
    report = EnergyAgentTeam().run(series, "Dashboard agent handoff")
    f = report["findings"]
    cards = [
        {"name": "Energy Data Analysis Agent", "short": "Load analyst", "status": "Complete", "summary": f"Mean load {f['analysis']['mean_kw']:.2f} kW; peak {f['analysis']['peak_kw']:.2f} kW at {f['analysis']['peak_time']}.", "evidence": f["analysis"], "tone": "cyan"},
        {"name": "Anomaly Detection Agent", "short": "Pattern watch", "status": "Complete", "summary": f"Flagged {f['anomalies']['count']} unusual hourly observations for review.", "evidence": f["anomalies"], "tone": "violet"},
        {"name": "Forecasting Agent", "short": "Demand forecast", "status": "Complete", "summary": f"Generated a 24-hour outlook; holdout MAE is {f['forecast']['metrics'].get('mae')!s} kW.", "evidence": f["forecast"], "tone": "blue"},
        {"name": "Energy Insight Agent", "short": "Insight synthesis", "status": "Complete", "summary": "Combined historical, anomaly, and forecast evidence into a traceable finding.", "evidence": {"evidence_refs": ["analysis", "anomalies", "forecast"]}, "tone": "amber"},
        {"name": "Decision Support Agent", "short": "Decision support", "status": "Complete", "summary": "Prepared operational review actions based on the measured evidence.", "evidence": {"recommendations": report["recommendations"]}, "tone": "green"},
    ]
    return _clean({"orchestrator": report["orchestrator"], "agents": cards, "handoffs": report["handoffs"], "recommendations": report["recommendations"]})


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=1200)
    days: int = Field(default=90, ge=7, le=1500)
    mode: Literal["local", "openrouter"] = "openrouter"


@app.post("/api/chat")
def chat(payload: ChatRequest):
    result = answer(payload.question.strip(), _window(payload.days), mode=payload.mode)
    return _clean(result)


frontend_dist = Path(__file__).resolve().parent / "frontend" / "dist"
if frontend_dist.is_dir():
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="frontend")
