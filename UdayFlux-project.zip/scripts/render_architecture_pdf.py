"""Render a lightweight PDF architecture diagram using PyMuPDF (fitz)."""
from pathlib import Path
import fitz

OUT = Path(__file__).resolve().parents[1] / "docs" / "architecture.pdf"
doc = fitz.open()
page = doc.new_page(width=900, height=620)
ink, blue, green, orange = (0.09, 0.17, 0.23), (0.92, 0.96, 0.98), (0.93, 0.97, 0.93), (1.0, 0.96, 0.89)
page.insert_text((220, 35), "Smart Grid Energy Intelligence Assistant", fontsize=20, color=ink)

def box(rect, title, detail, fill):
    shape = page.new_shape()
    shape.draw_rect(fitz.Rect(*rect))
    shape.finish(color=(0.23, 0.44, 0.56), fill=fill, width=1.4)
    shape.commit()
    x0, y0, x1, y1 = rect
    page.insert_textbox(fitz.Rect(x0+8, y0+8, x1-8, y0+31), title, fontsize=12, fontname="hebo", color=ink, align=1)
    page.insert_textbox(fitz.Rect(x0+8, y0+34, x1-8, y1-5), detail, fontsize=8.5, color=ink, align=1)

def arrow(start, end):
    page.draw_line(start, end, color=(0.29, 0.40, 0.48), width=1.6)

box((250, 55, 650, 105), "UCI Household Power TXT", "2.07M one-minute records - local source", blue)
box((210, 130, 690, 190), "Data processing & knowledge base", "Validate - clean - interpolate short gaps - create time features", blue)
arrow((450,105),(450,128))
box((35, 220, 285, 290), "Energy analytics", "Trends - peaks - hourly / weekday patterns", green)
box((325, 220, 575, 290), "Anomaly detection", "Rolling median / MAD - evidence records", green)
box((615, 220, 865, 290), "Forecasting", "Lag model - holdout MAE / RMSE / MAPE", green)
page.draw_line((450,190),(450,205),color=(0.29,0.40,0.48),width=1.5)
page.draw_line((160,205),(740,205),color=(0.29,0.40,0.48),width=1.5)
for x in (160,450,740): arrow((x,205),(x,218))
for x in (160,450,740): page.draw_line((x,290),(x,315),color=(0.29,0.40,0.48),width=1.5)
page.draw_line((160,315),(740,315),color=(0.29,0.40,0.48),width=1.5)
arrow((450,315),(450,330))
box((210, 332, 690, 392), "LangGraph agent orchestration", "Parallel Analysis / Anomaly / Forecast to Insight to Decision Support", orange)
arrow((450,392),(450,415))
box((210, 418, 690, 478), "Natural-language query & grounded insights", "Intent routing - evidence references - recommendations", orange)
arrow((450,478),(450,501))
box((210, 504, 690, 565), "React analyst application + FastAPI service", "Charts - agent studio - forecast - chat - evidence", blue)
doc.set_metadata({"title":"Smart Grid Energy Intelligence Assistant Architecture", "author":"Project documentation"})
doc.save(OUT)
print(f"Wrote {OUT}")
