from pathlib import Path
import requests

DEST = Path(__file__).resolve().parents[1] / "data" / "raw"
URL = "https://archive.ics.uci.edu/static/public/235/individual+household+electric+power+consumption.zip"

def main():
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST / "uci_household_power.zip"
    print(f"Downloading UCI dataset from {URL}")
    with requests.get(URL, stream=True, timeout=(20, 180)) as response:
        response.raise_for_status()
        with archive.open("wb") as f:
            for chunk in response.iter_content(1024*1024):
                if chunk: f.write(chunk)
    from zipfile import ZipFile
    with ZipFile(archive) as z:
        member = next((n for n in z.namelist() if n.lower().endswith("household_power_consumption.txt")), None)
        if member is None: raise RuntimeError("UCI archive did not contain the expected TXT data file")
        with z.open(member) as src, (DEST / "household_power_consumption.txt").open("wb") as dst:
            while chunk := src.read(1024*1024): dst.write(chunk)
    print(f"Saved {DEST / 'household_power_consumption.txt'}")

if __name__ == "__main__": main()
