import pandas as pd
import plotly.express as px
import streamlit as st
from energy_assistant.data import load_data, hourly_series
from energy_assistant.analytics import summarize, detect_anomalies, forecast
from energy_assistant.query import answer
from energy_assistant.agents import EnergyAgentTeam

st.set_page_config(page_title="UdayFlux | Smart Grid Energy Intelligence", page_icon="⚡", layout="wide")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap');
html, body, button, input, textarea, select, [class*="st-"], [data-testid] {
    font-family: 'Abril Fatface', serif !important;
}
</style>
""", unsafe_allow_html=True)
st.title("⚡ UdayFlux Energy Intelligence")
st.caption("Data-grounded household electricity analytics · UCI dataset · kW unless stated otherwise")

@st.cache_data(show_spinner="Loading and validating the energy dataset…")
def get_data():
    return load_data()

try:
    minute, quality = get_data()
except Exception as exc:
    st.error(str(exc))
    st.markdown("Download the dataset with `python scripts/download_data.py`, then refresh this page.")
    st.stop()

st.sidebar.header("Analysis window")
min_d, max_d = minute.index.min().date(), minute.index.max().date()
dates = st.sidebar.date_input("Date range", value=(max_d-pd.Timedelta(days=90), max_d), min_value=min_d, max_value=max_d)
if isinstance(dates, tuple) and len(dates)==2:
    start, end = pd.Timestamp(dates[0]), pd.Timestamp(dates[1])+pd.Timedelta(days=1)-pd.Timedelta(seconds=1)
else: start,end=pd.Timestamp(min_d),pd.Timestamp(max_d)
filtered=minute.loc[start:end]
series=hourly_series(filtered)
if series.empty: st.warning("No observations in this date range."); st.stop()
stats=summarize(series)

with st.expander("Data quality and preprocessing", expanded=False):
    st.write("Calendar timestamps parsed in day/month/year format. Invalid timestamps are dropped; duplicate timestamps keep the last record. Numeric `?` values are treated as missing. Gaps up to 60 minutes are time-interpolated; longer missing runs remain missing. Hourly demand uses the mean of available minute readings.")
    st.json(quality)

k1,k2,k3,k4=st.columns(4)
k1.metric("Mean hourly demand",f"{stats['mean_kw']:.2f} kW")
k2.metric("Peak hourly mean",f"{stats['max_kw']:.2f} kW",stats['peak_time'][:16])
k3.metric("Unusual hours",f"{len(detect_anomalies(series)):,}")
future, metrics=forecast(series,24)
k4.metric("Next 24h forecast mean",f"{future.mean():.2f} kW")

tabs=st.tabs(["Overview","Anomalies","Forecast","Ask the assistant","Evaluation & agents"])
with tabs[0]:
    st.subheader("Hourly demand")
    view=series.resample("3h").mean() if len(series)>3000 else series
    st.plotly_chart(px.line(x=view.index,y=view.values,labels={"x":"Time","y":"Active power (kW)"},title="Global active power"),use_container_width=True)
    c1,c2=st.columns(2)
    c1.plotly_chart(px.bar(x=stats["hourly_mean_kw"].index,y=stats["hourly_mean_kw"].values,labels={"x":"Hour of day","y":"Mean kW"},title="Average demand by hour"),use_container_width=True)
    dow=stats["dow_mean_kw"]
    c2.plotly_chart(px.bar(x=dow.index,y=dow.values,labels={"x":"Day","y":"Mean kW"},title="Average demand by weekday"),use_container_width=True)
    st.caption("Dataset describes one household in Sceaux, France. It is not a multi-region grid dataset.")
with tabs[1]:
    st.subheader("Robust rolling median/MAD anomaly evidence")
    anomalies=detect_anomalies(series)
    if anomalies.empty: st.info("No hours crossed robust-score threshold 4.5 in this window.")
    else:
        chosen=anomalies.sort_index()
        fig=px.scatter(x=chosen.index,y=chosen.observed_kw,color=chosen.robust_score,labels={"x":"Time","y":"Observed kW","color":"Robust score"},title="Flagged unusual hourly demand")
        st.plotly_chart(fig,use_container_width=True)
        st.dataframe(anomalies.head(100),use_container_width=True)
    st.caption("Unsupervised flags are candidates for analyst review; the source has no anomaly labels, so precision/recall is not reported.")
with tabs[2]:
    st.subheader("24-hour demand forecast")
    hist=series.iloc[-min(24*14,len(series)):]
    st.plotly_chart(px.line(x=list(hist.index)+list(future.index),y=list(hist.values)+list(future.values),color=["History"]*len(hist)+["Forecast"]*len(future),labels={"x":"Time","y":"Demand (kW)","color":"Series"}),use_container_width=True)
    st.json(metrics)
    st.dataframe(future.rename("forecast_kw"),use_container_width=True)
with tabs[3]:
    st.subheader("Ask an energy question")
    st.caption("When OpenRouter is enabled, your question and only the analytics evidence needed for the answer are sent to the configured model provider. The raw minute-level dataset is not sent.")
    question=st.text_input("Question",placeholder="What was the peak demand, and what evidence supports it?")
    if st.button("Analyze",type="primary") and question.strip():
        result=answer(question,series)
        st.markdown(result["answer"])
        mode = result.get("provider", "Local analytics")
        if result.get("model"):
            mode += " / " + result["model"]
        st.caption("Answer mode: " + mode + " · Evidence tools: " + (", ".join(result["sources"]) or "none"))
        if result.get("mode_note"):
            st.info(result["mode_note"])
        with st.expander("Inspect supporting evidence",expanded=True): st.json(result["evidence"])
with tabs[4]:
    st.subheader("Model evaluation")
    st.write("Chronological holdout, compared with previous-day seasonal naive baseline. Forecast quality varies with the selected date window.")
    st.json(metrics)
    st.write("Anomaly effectiveness is reviewed using threshold behavior and analyst-visible event records; no ground-truth labels exist in the supplied source. Natural-language routing maps supported terms to deterministic query handlers, and every numeric answer references computed evidence.")
    st.subheader("Multi-agent handoff trace")
    report=EnergyAgentTeam().run(series,"Dashboard evaluation handoff")
    st.write(" → ".join(report["agents"]))
    st.dataframe(pd.DataFrame(report["handoffs"])[["sender","recipient","kind","message_id"]],use_container_width=True)
    st.subheader("Decision support")
    for recommendation in report["recommendations"]: st.write("• "+recommendation)
