# UdayFlux — Smart Grid Energy Intelligence Assistant

An evidence-first analytics application for the UCI Individual Household Electric Power Consumption dataset. It provides data quality reporting, load trends and peak periods, explainable anomaly detection, evaluated short-horizon forecasts, a natural-language query interface, and a five-role agent workflow with traceable evidence.

## Quick start

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn api:app --reload --port 8000
```

In a **second PowerShell window**:

```powershell
cd C:\Users\Administrator\Desktop\CapstoneV\frontend
npm install
npm run dev
```

Open the Vite URL printed in that window (usually `http://localhost:5173`). The API runs at `http://localhost:8000`. The UCI dataset is already in `data/raw`; use `python scripts/download_data.py` only if it is missing.

To enable generative answers, add your OpenRouter key to `.env` as `OPENROUTER_API_KEY=...` and restart the API server. `OPENROUTER_MODEL` defaults to `openrouter/auto`; set it to another tool-calling model slug if preferred. Keep `.env` private. With OpenRouter enabled, the user's question and required computed evidence are sent to the selected model provider; the raw minute-level dataset is not sent. Without a key, the application uses its local deterministic query router.

For a single-server run after building the frontend:

```powershell
cd C:\Users\Administrator\Desktop\CapstoneV\frontend
npm run build
cd ..
uvicorn api:app --port 8000
```

Then open `http://localhost:8000`.

In the React dashboard, energy visualizations are collapsed initially. Use **Open chart** or **Open visualization** in a section to reveal each graph.

Dataset: [UCI Individual Household Electric Power Consumption](https://archive.ics.uci.edu/dataset/235/individualhouseholdelectricpowerconsumption), CC BY 4.0. The downloader saves the original archive under `data/raw/`; the app also accepts the semicolon-delimited TXT file there. If download access is unavailable, use the UCI dataset page to download its ZIP and extract `household_power_consumption.txt` into `data/raw/`.

## Architecture

See [docs/architecture.md](docs/architecture.md), [docs/architecture.pdf](docs/architecture.pdf), and [docs/architecture.svg](docs/architecture.svg). The React/Vite client talks to a local FastAPI service; cached analytics load the 2.07 million minute observations once. When OpenRouter is configured, the LLM selects local analytics tools, receives their measured results, and writes a grounded explanation. The available tools cover trends/peaks, anomaly evidence, demand forecasts, and the multi-agent team. Tool outputs remain visible for traceability. Without a key or if the provider is unavailable, the local deterministic query router is used.

## Capabilities

- Validates and parses dates/times, coerces invalid numeric values, excludes clearly invalid timestamps, interpolates short gaps for modeling while retaining quality counts, and builds calendar features.
- Uses hourly aggregation for dashboard analytics. Reports peak hours, day-of-week and monthly patterns, and consumption change.
- Detects anomalies with a rolling median/MAD robust score and reports timestamp, observed value, baseline, and deviation. A robust fallback handles zero MAD.
- Forecasts hourly demand with a seasonal-naive (same hour previous day) baseline and a regularized lag/rolling regression model when enough history exists. A chronological holdout reports MAE, RMSE and guarded MAPE. Forecast charts show the selected model.
- Provides an Evaluation dashboard section with selected-window forecast scores, a seasonal-naive comparison, data-quality counts, and transparent notes where anomaly or language quality cannot be scored without labels.
- Uses OpenRouter function/tool calling for flexible natural-language questions; the model can invoke local trend, anomaly, forecasting, and multi-agent analytics and then explain their evidence. A deterministic local router remains as the no-key and provider-failure fallback.
- LangGraph orchestrates five specialized agent roles (analysis, anomaly, forecasting, insight, decision support): analysis, anomaly, and forecast nodes run in parallel, then join at the insight node before decision support. Structured handoffs include evidence and message IDs.

## Sample questions

- “When was the peak demand?”
- “Find unusual consumption in the selected period.”
- “What is the expected demand for the next 24 hours?”
- “Why did consumption increase?”
- “Give operational insights.”

Responses identify the queried data window, units, and evidence references. The source is one household in Sceaux, France; it should not be interpreted as a regional grid dataset.

## Evaluation

Forecast model and seasonal-naive baseline are evaluated on the final chronological holdout. Anomaly detection is unsupervised and this dataset has no anomaly labels, so precision/recall cannot be honestly claimed; the UI exposes anomaly counts, severity, and supporting records for analyst review. Query quality is supported by tool schemas, visible tool/evidence outputs, and a deterministic fallback. Generated answers still require evaluation against annotated questions. See [docs/design.md](docs/design.md).

## Structure

`frontend/` is the React/Vite interface; `api.py` exposes the FastAPI service; `energy_assistant/` contains data, analytics, agent and query modules; `scripts/` contains dataset and architecture utilities; `app.py` remains as a legacy Streamlit interface.

For the requested 10-minute presentation format, see [docs/demo_script.md](docs/demo_script.md).

## License and attribution

Code in this project is provided under the MIT License. Dataset attribution: Hebrail, G. & Berard, A. (2006), *Individual Household Electric Power Consumption*, UCI Machine Learning Repository, DOI: [10.24432/C58K54](https://doi.org/10.24432/C58K54), CC BY 4.0.
