import logging
import os
from .analytics import summarize, detect_anomalies
from .agents import EnergyAgentTeam
from .llm import answer_with_openrouter

INTENTS = {
    "peak": ["peak", "maximum", "highest"],
    "anomaly": ["anomal", "unusual", "spike", "abnormal"],
    "forecast": ["forecast", "expected", "predict", "next", "future"],
    "trend": ["trend", "increase", "decrease", "change", "historical", "season", "insight"],
}


def _deterministic_answer(question: str, series) -> dict:
    q = question.lower()
    if any(w in q for w in ["why", "recommend", "operational", "insight", "complex"]):
        report = EnergyAgentTeam().run(series, question)
        a=report["findings"]["analysis"]; an=report["findings"]["anomalies"]; f=report["findings"]["forecast"]["metrics"]
        mae = f.get("mae")
        mae_text = f"{mae:.3f} kW" if mae is not None else "unavailable for this short window"
        text=(f"Across {series.index.min():%Y-%m-%d} to {series.index.max():%Y-%m-%d}, mean hourly demand was {a['mean_kw']:.2f} kW and the recorded peak was {a['peak_kw']:.2f} kW at {a['peak_time']}. "
              f"The robust detector flagged {an['count']} unusual hours. The forecasting holdout MAE was {mae_text}. "
              "The supplied evidence describes association and unusualness; it cannot establish the cause of a change.")
        return {"intent":"multi-agent insight and decision support","answer":text,"evidence":report,"sources":["analysis","anomalies","forecast"]}
    intent = next((name for name, terms in INTENTS.items() if any(term in q for term in terms)), None)
    if intent == "peak":
        s=summarize(series); return {"intent":intent,"answer":f"The highest hourly mean was {s['max_kw']:.2f} kW at {s['peak_time']}.","evidence":{"peak_kw":s['max_kw'],"peak_time":s['peak_time']},"sources":["hourly series max"]}
    if intent == "anomaly":
        a=detect_anomalies(series).head(10)
        return {"intent":intent,"answer":f"The detector flagged {len(detect_anomalies(series))} unusual hours at robust score ≥ 4.5. Showing up to 10 highest scores with measured value, rolling baseline, and deviation.","evidence":a.reset_index().to_dict(orient="records"),"sources":["rolling median/MAD"]}
    if intent == "forecast":
        from .analytics import forecast
        result, metrics=forecast(series,24)
        return {"intent":intent,"answer":f"Forecasted mean demand over the next 24 hours is {result.mean():.2f} kW. Chronological holdout MAE: {metrics.get('mae', float('nan')):.3f} kW.","evidence":{"forecast":result.reset_index().rename(columns={"index":"timestamp"}).to_dict(orient="records"),"metrics":metrics},"sources":["forecast model","chronological holdout"]}
    if intent == "trend":
        s=summarize(series); return {"intent":intent,"answer":f"Mean hourly demand is {s['mean_kw']:.2f} kW. The first-to-last hourly change in this selected window is {s['change_pct']:.1f}%. Highest mean hour of day: {s['peak_hour']:02d}:00.","evidence":{"hourly_mean_kw":s['hourly_mean_kw'].to_dict(),"change_pct":s['change_pct']},"sources":["hourly series","hour-of-day aggregate"]}
    return {"intent":"unsupported","answer":"I can answer questions about peak demand, anomalies, forecasts, trends, seasonal patterns, demand changes, or operational insights. Please ask about one of those topics.","evidence":{},"sources":[]}


def answer(question: str, series, api_key: str | None = None, mode: str = "auto") -> dict:
    """Answer with OpenRouter, local analytics, or automatic fallback."""
    if mode == "local":
        result = _deterministic_answer(question, series)
        result["provider"] = "Local analytics"
        result["mode_note"] = "Local analytics was selected; no LLM provider was used."
        return result

    key = api_key or os.getenv("OPENROUTER_API_KEY")
    if key:
        try:
            return answer_with_openrouter(question, series, key)
        except Exception as exc:
            # Keep the analyst UI usable during network, model, or provider failures.
            result = _deterministic_answer(question, series)
            result["provider"] = "Local fallback"
            logging.exception("OpenRouter request failed; using local analytics fallback")
            detail = str(exc).strip()
            suffix = f" ({type(exc).__name__}: {detail[:240]})" if detail else f" ({type(exc).__name__})"
            result["mode_note"] = f"OpenRouter request failed{suffix}; this answer came from the local analytics router."
            return result
    result = _deterministic_answer(question, series)
    result["provider"] = "Local fallback" if mode == "openrouter" else "Local analytics"
    if mode == "openrouter":
        result["mode_note"] = "No OpenRouter API key is configured; this answer came from local analytics."
    return result
