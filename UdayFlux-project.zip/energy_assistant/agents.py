"""LangGraph orchestration for the specialist energy-agent workflow."""
from dataclasses import asdict, dataclass
from typing import Any, TypedDict
from uuid import uuid4

import pandas as pd
from langgraph.graph import END, START, StateGraph

from .analytics import detect_anomalies, forecast, summarize


@dataclass
class AgentMessage:
    sender: str
    recipient: str
    kind: str
    evidence: dict
    message_id: str


class EnergyAgentState(TypedDict, total=False):
    series: pd.Series
    question: str
    horizon: int
    analysis: dict[str, Any]
    anomalies: dict[str, Any]
    forecast_result: dict[str, Any]
    insight: dict[str, Any]
    handoffs: list[dict]
    recommendations: list[str]


ANALYSIS = "Energy Data Analysis Agent"
ANOMALY = "Anomaly Detection Agent"
FORECAST = "Forecasting Agent"
INSIGHT = "Energy Insight Agent"
DECISION = "Decision Support Agent"


def _analysis_node(state: EnergyAgentState) -> dict:
    stats = summarize(state["series"])
    evidence = {
        "mean_kw": stats.get("mean_kw"),
        "peak_kw": stats.get("max_kw"),
        "peak_time": stats.get("peak_time"),
        "change_pct": stats.get("change_pct"),
    }
    return {"analysis": evidence}


def _anomaly_node(state: EnergyAgentState) -> dict:
    found = detect_anomalies(state["series"])
    top = found.head(5).reset_index().to_dict(orient="records")
    return {"anomalies": {"count": len(found), "top": top}}


def _forecast_node(state: EnergyAgentState) -> dict:
    future, metrics = forecast(state["series"], state.get("horizon", 24))
    values = future.rename("forecast_kw").rename_axis("timestamp").reset_index().to_dict(orient="records")
    return {"forecast_result": {"values": values, "metrics": metrics}}


def _message(sender: str, recipient: str, kind: str, evidence: dict) -> dict:
    return asdict(AgentMessage(sender, recipient, kind, evidence, str(uuid4())[:8]))


def _insight_node(state: EnergyAgentState) -> dict:
    analysis = state["analysis"]
    anomalies = state["anomalies"]
    forecast_evidence = state["forecast_result"]
    metrics = forecast_evidence["metrics"]
    insight = {
        "question": state.get("question", "Energy intelligence summary"),
        "summary": (
            f"Mean demand was {analysis['mean_kw']:.2f} kW, with a peak of "
            f"{analysis['peak_kw']:.2f} kW at {analysis['peak_time']}. "
            f"The anomaly detector flagged {anomalies['count']} hours. "
            f"Forecast holdout MAE: {metrics.get('mae')} kW."
        ),
        "evidence_refs": ["analysis", "anomalies", "forecast"],
    }
    handoffs = [
        _message(ANALYSIS, INSIGHT, "historical_summary", analysis),
        _message(ANOMALY, INSIGHT, "anomaly_evidence", anomalies),
        _message(FORECAST, INSIGHT, "forecast_evidence", metrics),
        _message(INSIGHT, DECISION, "combined_insight", insight),
    ]
    return {"insight": insight, "handoffs": handoffs}


def _decision_node(state: EnergyAgentState) -> dict:
    analysis = state["analysis"]
    anomalies = state["anomalies"]
    recommendations = []
    if analysis["peak_kw"] is not None:
        recommendations.append(
            f"Review operational readiness around the observed peak at {analysis['peak_time']} ({analysis['peak_kw']:.2f} kW)."
        )
    if anomalies["count"]:
        recommendations.append(
            f"Review the {min(anomalies['count'], 5)} highest-scoring unusual hour(s) against household activity and meter quality before taking action."
        )
    else:
        recommendations.append("No hours exceeded the configured robust anomaly threshold in this window; continue routine monitoring.")
    recommendations.append("Treat this single-household history as a load-shape example, not a regional grid capacity signal.")
    return {"recommendations": recommendations}


def _build_graph():
    """Run analytical specialists in parallel, then join for insight and decisions."""
    workflow = StateGraph(EnergyAgentState)
    workflow.add_node(ANALYSIS, _analysis_node)
    workflow.add_node(ANOMALY, _anomaly_node)
    workflow.add_node(FORECAST, _forecast_node)
    workflow.add_node(INSIGHT, _insight_node)
    workflow.add_node(DECISION, _decision_node)
    workflow.add_edge(START, ANALYSIS)
    workflow.add_edge(START, ANOMALY)
    workflow.add_edge(START, FORECAST)
    workflow.add_edge([ANALYSIS, ANOMALY, FORECAST], INSIGHT)
    workflow.add_edge(INSIGHT, DECISION)
    workflow.add_edge(DECISION, END)
    return workflow.compile()


_COMPILED_GRAPH = None


class EnergyAgentTeam:
    """LangGraph fan-out/fan-in workflow with explicit evidence handoffs."""
    roles = [ANALYSIS, ANOMALY, FORECAST, INSIGHT, DECISION]

    def __init__(self):
        global _COMPILED_GRAPH
        if _COMPILED_GRAPH is None:
            _COMPILED_GRAPH = _build_graph()
        self.graph = _COMPILED_GRAPH

    def run(self, series: pd.Series, question: str, horizon: int = 24) -> dict:
        result = self.graph.invoke({"series": series, "question": question, "horizon": horizon})
        findings = {
            "analysis": result["analysis"],
            "anomalies": result["anomalies"],
            "forecast": result["forecast_result"],
            "insight": result["insight"],
        }
        return {
            "agents": self.roles,
            "orchestrator": "LangGraph StateGraph",
            "findings": findings,
            "handoffs": result["handoffs"],
            "recommendations": result["recommendations"],
        }
