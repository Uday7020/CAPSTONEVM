from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "raw" / "household_power_consumption.txt"
NUMERIC = ["Global_active_power", "Global_reactive_power", "Voltage", "Global_intensity", "Sub_metering_1", "Sub_metering_2", "Sub_metering_3"]


def load_data(path: str | Path = DATA_FILE) -> tuple[pd.DataFrame, dict]:
    """Read and clean the original UCI semicolon-delimited TXT file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found at {path}. Run: python scripts/download_data.py")
    raw = pd.read_csv(path, sep=";", na_values=["?", ""], low_memory=False)
    raw.columns = [str(c).strip() for c in raw.columns]
    required = {"Date", "Time", *NUMERIC}
    if not required.issubset(raw.columns):
        raise ValueError(f"Unexpected dataset columns; missing: {sorted(required - set(raw.columns))}")
    rows_input = len(raw)
    stamps = pd.to_datetime(raw["Date"].astype(str).str.strip() + " " + raw["Time"].astype(str).str.strip(), dayfirst=True, errors="coerce")
    invalid_ts = int(stamps.isna().sum())
    raw["timestamp"] = stamps
    raw = raw.dropna(subset=["timestamp"]).drop_duplicates("timestamp", keep="last").set_index("timestamp").sort_index()
    for col in NUMERIC:
        raw[col] = pd.to_numeric(raw[col], errors="coerce")
    missing = int(raw["Global_active_power"].isna().sum())
    raw[NUMERIC] = raw[NUMERIC].interpolate(method="time", limit=60, limit_direction="both")
    # Remaining long gaps are not fabricated; downstream resampling ignores them.
    raw["hour"] = raw.index.hour
    raw["day_of_week"] = raw.index.dayofweek
    raw["month"] = raw.index.month
    raw["is_weekend"] = raw.index.dayofweek >= 5
    raw["active_energy_kwh"] = raw["Global_active_power"] / 60.0
    quality = {"rows_input": rows_input, "rows_clean": len(raw), "invalid_timestamps": invalid_ts,
               "missing_active_power_before_interpolation": missing,
               "missing_active_power_after_interpolation": int(raw["Global_active_power"].isna().sum()),
               "duplicate_timestamps_removed": rows_input - invalid_ts - len(raw),
               "time_range_start": str(raw.index.min()), "time_range_end": str(raw.index.max())}
    return raw, quality


def hourly_series(frame: pd.DataFrame) -> pd.Series:
    return frame["Global_active_power"].resample("h").mean().dropna().rename("demand_kw")
