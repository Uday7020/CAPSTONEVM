import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error


def summarize(series: pd.Series) -> dict:
    if series.empty:
        return {}
    hourly_mean = series.groupby(series.index.hour).mean()
    return {"mean_kw": float(series.mean()), "max_kw": float(series.max()), "min_kw": float(series.min()),
            "peak_time": series.idxmax().isoformat(), "peak_hour": int(hourly_mean.idxmax()),
            "daily_mean_kw": float(series.resample("D").mean().mean()),
            "monthly_mean_kw": series.resample("MS").mean(), "hourly_mean_kw": hourly_mean,
            "dow_mean_kw": series.groupby(series.index.day_name()).mean(),
            "change_pct": float((series.iloc[-1] / series.iloc[0] - 1) * 100) if len(series)>1 and series.iloc[0] else 0.0}


def detect_anomalies(series: pd.Series, window: int = 24 * 7, threshold: float = 4.5) -> pd.DataFrame:
    """Robust rolling median/MAD anomaly detector; scores are inspectable."""
    baseline = series.rolling(window, min_periods=max(6, window // 4), center=True).median()
    residual = series - baseline
    mad = residual.abs().rolling(window, min_periods=max(6, window // 4), center=True).median()
    scale = 1.4826 * mad
    # Avoid division by zero while preserving explicit deviation evidence.
    score = residual.abs() / scale.replace(0, np.nan)
    score = score.fillna(0)
    mask = score >= threshold
    result = pd.DataFrame({"observed_kw": series[mask], "baseline_kw": baseline[mask], "deviation_kw": residual[mask], "robust_score": score[mask]})
    return result.sort_values("robust_score", ascending=False)


def _features(series: pd.Series) -> tuple[pd.DataFrame, pd.Series]:
    df = pd.DataFrame({"y": series})
    for lag in [1, 2, 3, 24, 25, 48, 168]:
        df[f"lag_{lag}"] = df.y.shift(lag)
    df["roll_24"] = df.y.shift(1).rolling(24).mean()
    df["hour"] = df.index.hour
    df["dow"] = df.index.dayofweek
    df["month"] = df.index.month
    return df.dropna().drop(columns="y"), df.dropna().y


def forecast(series: pd.Series, horizon: int = 24) -> tuple[pd.Series, dict]:
    """Chronological validation against seasonal-naive, then recursive boosted-tree forecast."""
    series = series.asfreq("h").interpolate(limit=3).dropna()
    if len(series) < 24 * 10:
        naive = series.iloc[-min(24, len(series)):].mean()
        idx = pd.date_range(series.index[-1] + pd.Timedelta(hours=1), periods=horizon, freq="h")
        return pd.Series(naive, index=idx, name="forecast_kw"), {"model":"mean fallback", "mae":None,"rmse":None,"mape":None}
    x, y = _features(series)
    holdout = max(24, min(24 * 7, len(y) // 5))
    train_x, test_x = x.iloc[:-holdout], x.iloc[-holdout:]
    train_y, test_y = y.iloc[:-holdout], y.iloc[-holdout:]
    model = HistGradientBoostingRegressor(max_iter=100, learning_rate=.08, max_leaf_nodes=15, l2_regularization=1.0, random_state=42)
    model.fit(train_x, train_y)
    pred = pd.Series(model.predict(test_x), index=test_y.index)
    seasonal = series.shift(24).reindex(test_y.index)
    seasonal = seasonal.fillna(train_y.mean())
    mae = float(mean_absolute_error(test_y, pred)); rmse = float(np.sqrt(mean_squared_error(test_y, pred)))
    mape = float((np.abs((test_y-pred)/test_y.replace(0,np.nan))).dropna().mean()*100)
    base_mae = float(mean_absolute_error(test_y, seasonal))
    metrics = {"model":"HistGradientBoostingRegressor", "mae":mae, "rmse":rmse,"mape":mape,"baseline_mae":base_mae,"holdout_hours":len(test_y),"holdout_start":str(test_y.index.min()),"holdout_end":str(test_y.index.max())}
    # Fit to all available supervised examples, then recursively predict.
    model.fit(x, y)
    history = series.copy()
    outputs = []
    for _ in range(horizon):
        t = history.index[-1] + pd.Timedelta(hours=1)
        row = {f"lag_{lag}": history.iloc[-lag] for lag in [1,2,3,24,25,48,168]}
        row.update({"roll_24":history.iloc[-24:].mean(), "hour":t.hour,"dow":t.dayofweek,"month":t.month})
        val = float(model.predict(pd.DataFrame([row]))[0])
        outputs.append(val); history.loc[t] = val
    idx = pd.date_range(series.index[-1] + pd.Timedelta(hours=1), periods=horizon, freq="h")
    return pd.Series(outputs,index=idx,name="forecast_kw"), metrics
