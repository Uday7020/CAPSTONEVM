import { useEffect, useMemo, useState } from 'react'
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, Bot, ChevronDown, ChevronRight,
  CircleHelp, ClipboardCheck, Clock3, Command, Cpu, Gauge, LayoutDashboard, MessageSquareText,
  Radio, RefreshCw, Search, ShieldAlert, Sparkles, Zap,
} from 'lucide-react'

const periods = [{ label: '7D', days: 7 }, { label: '30D', days: 30 }, { label: '90D', days: 90 }, { label: 'ALL', days: 1500 }]

function fmt(value, digits = 2) { return Number.isFinite(Number(value)) ? Number(value).toFixed(digits) : '—' }
function when(value) { return value ? new Date(value).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—' }

function BrandMark() { return <div className="brand-mark"><Zap size={18} fill="currentColor" /></div> }

function NavItem({ active, icon: Icon, children, onClick, badge }) {
  return <button className={`nav-item ${active ? 'active' : ''}`} onClick={onClick}><Icon size={17} strokeWidth={1.8} /><span>{children}</span>{badge && <small>{badge}</small>}</button>
}

function Chart({ data = [], forecast = [], color = '#315d3c', area = true, height = 255, anomalies = [] }) {
  const W = 1000, H = height, pad = { l: 50, r: 20, t: 18, b: 33 }
  const all = [...data, ...forecast]
  if (!all.length) return <div className="chart-empty">Waiting for energy data…</div>
  const vals = all.map(d => Number(d.value) || 0)
  let min = Math.min(...vals), max = Math.max(...vals)
  if (max === min) { max += 1; min -= 1 }
  const x = i => pad.l + i / Math.max(1, all.length - 1) * (W - pad.l - pad.r)
  const y = v => pad.t + (max - v) / (max - min) * (H - pad.t - pad.b)
  const pts = all.map((d, i) => [x(i), y(Number(d.value) || 0)])
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ')
  const split = data.length
  const forecastLine = pts.slice(Math.max(0, split - 1)).map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ')
  const areaPath = `${line} L${pts.at(-1)[0]},${H - pad.b} L${pts[0][0]},${H - pad.b} Z`
  const labels = [data[0]?.time, data[Math.floor(data.length / 2)]?.time, data.at(-1)?.time, forecast.at(-1)?.time].filter(Boolean)
  return <div className="chart-wrap"><svg className="line-chart" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label="Electricity demand chart">
    <defs><linearGradient id="chart-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity=".19"/><stop offset="100%" stopColor={color} stopOpacity="0"/></linearGradient><filter id="glow"><feGaussianBlur stdDeviation="3" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
    {[0, 1, 2, 3].map(i => { const gy = pad.t + i * (H - pad.t - pad.b) / 3; const value = max - (max - min) * i / 3; return <g key={i}><line x1={pad.l} x2={W - pad.r} y1={gy} y2={gy} className="chart-grid"/><text x={pad.l - 10} y={gy + 4} className="chart-label" textAnchor="end">{value.toFixed(1)}</text></g> })}
    {area && <path d={areaPath} fill="url(#chart-fill)"/>}
    <path d={line} fill="none" stroke={color} strokeWidth="2.6" strokeLinejoin="round" strokeLinecap="round" filter="url(#glow)" vectorEffect="non-scaling-stroke"/>
    {forecast.length > 0 && <path d={forecastLine} fill="none" stroke="#8a6440" strokeWidth="2.4" strokeDasharray="7 7" strokeLinecap="round" vectorEffect="non-scaling-stroke"/>}
    {anomalies.slice(0, 18).map((a, i) => { const ix = data.findIndex(d => d.time === a.timestamp); return ix < 0 ? null : <circle key={i} cx={x(ix)} cy={y(data[ix].value)} r="4.2" fill="#805239" stroke="#3b2d21" strokeWidth="2"/> })}
    {labels.map((v, i) => <text key={i} x={pad.l + i * (W - pad.l - pad.r) / Math.max(1, labels.length - 1)} y={H - 8} className="chart-label" textAnchor={i === 0 ? 'start' : i === labels.length - 1 ? 'end' : 'middle'}>{new Date(v).toLocaleDateString([], { month: 'short', day: 'numeric' })}</text>)}
  </svg></div>
}

function MetricCard({ label, value, unit, icon: Icon, trend, tone = 'mint', foot }) {
  return <article className={`metric-card tone-${tone}`}><div className="metric-top"><span>{label}</span><span className="metric-icon"><Icon size={17}/></span></div><div className="metric-value">{value}<small>{unit}</small></div><div className="metric-foot">{trend && <span className={trend > 0 ? 'trend-up' : 'trend-down'}>{trend > 0 ? <ArrowUpRight size={13}/> : <ArrowDownRight size={13}/>} {Math.abs(trend).toFixed(1)}%</span>}{foot}</div></article>
}

function MiniBars({ data = [] }) {
  const max = Math.max(...data.map(d => Number(d.value) || 0), .01)
  return <div className="mini-bars">{data.map((d, i) => <div key={i} className="bar-col"><div className="bar-tip">{fmt(d.value)} kW</div><span style={{ height: `${Math.max(5, Number(d.value) / max * 100)}%`, animationDelay: `${i * 22}ms` }}/><small>{d.hour ?? d.day?.slice(0, 3)}</small></div>)}</div>
}

const agentMeta = [
  { name: 'Energy Data Analysis Agent', short: 'Load analyst', icon: Activity, tone: 'cyan', role: 'Reads the selected demand window and extracts load levels, peak periods, and calendar patterns.' },
  { name: 'Anomaly Detection Agent', short: 'Pattern watch', icon: ShieldAlert, tone: 'violet', role: 'Reviews hourly observations against the rolling median/MAD baseline and returns flagged evidence.' },
  { name: 'Forecasting Agent', short: 'Demand forecast', icon: Radio, tone: 'blue', role: 'Builds the next-day outlook and reports chronological holdout accuracy against a seasonal baseline.' },
  { name: 'Energy Insight Agent', short: 'Insight synthesis', icon: Sparkles, tone: 'amber', role: 'Combines historical, anomaly, and forecast evidence into one grounded explanation.' },
  { name: 'Decision Support Agent', short: 'Decision support', icon: Gauge, tone: 'green', role: 'Turns the combined evidence into practical recommendations for analyst review.' },
]

function App() {
  const [section, setSection] = useState('overview')
  const [days, setDays] = useState(90)
  const [refreshId, setRefreshId] = useState(0)
  const [dash, setDash] = useState(null)
  const [agentData, setAgentData] = useState(null)
  const [selectedAgent, setSelectedAgent] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [question, setQuestion] = useState('')
  const [chatBusy, setChatBusy] = useState(false)
  const [chatMode, setChatMode] = useState('openrouter')
  const [messages, setMessages] = useState([{ role: 'assistant', text: 'Hey there. I’m UdayFlux, your energy intelligence copilot. Ask me about demand peaks, unusual behavior, forecasts, or what the evidence suggests.' }])
  const [openEvidence, setOpenEvidence] = useState(null)

  useEffect(() => {
    let active = true
    setLoading(true); setError('')
    fetch(`/api/dashboard?days=${days}`).then(r => { if (!r.ok) throw new Error(`API returned ${r.status}. Is the backend running?`); return r.json() }).then(d => { if (active) setDash(d) }).catch(e => { if (active) setError(e.message) }).finally(() => { if (active) setLoading(false) })
    setAgentData(null)
    return () => { active = false }
  }, [days, refreshId])

  useEffect(() => {
    if (!['agents', 'evaluation'].includes(section) || agentData) return
    fetch(`/api/agents?days=${days}`).then(r => r.ok ? r.json() : Promise.reject(new Error('Could not load agent report'))).then(setAgentData).catch(e => setError(e.message))
  }, [section, days, agentData])

  const nav = (id) => { setSection(id); setError('') }
  const prompt = p => { setQuestion(p); setSection('chat') }
  const send = async (text = question) => {
    const q = text.trim(); if (!q || chatBusy) return
    setMessages(m => [...m, { role: 'user', text: q }]); setQuestion(''); setChatBusy(true); setOpenEvidence(null)
    try {
      const response = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: q, days, mode: chatMode }) })
      const body = await response.json()
      if (!response.ok) throw new Error(body.detail || 'Could not get an answer')
      setMessages(m => [...m, { role: 'assistant', text: body.answer, provider: body.provider, model: body.model, sources: body.sources || [], evidence: body.evidence, note: body.mode_note }])
    } catch (e) { setMessages(m => [...m, { role: 'assistant', text: `I couldn't reach the intelligence service: ${e.message}. Check that the API is running and try again.`, error: true }]) }
    finally { setChatBusy(false) }
  }

  const greetingDate = new Intl.DateTimeFormat('en', { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date())
  const metric = dash?.metrics

  return <div className="app-shell">
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <aside className="sidebar">
      <div className="brand"><BrandMark/><span>UdayFlux<span className="brand-dot">.</span></span><div className="brand-beta">AI</div></div>
      <div className="workspace-switch"><div className="workspace-avatar">E</div><div><strong>Energy Ops</strong><small>Analyst workspace</small></div><ChevronDown size={15}/></div>
      <div className="nav-label">WORKSPACE</div>
      <nav className="primary-nav">
        <NavItem active={section === 'overview'} icon={LayoutDashboard} onClick={() => nav('overview')}>Overview</NavItem>
        <NavItem active={section === 'agents'} icon={Cpu} onClick={() => nav('agents')} badge="5">Agent studio</NavItem>
        <NavItem active={section === 'anomalies'} icon={ShieldAlert} onClick={() => nav('anomalies')}>Anomaly watch</NavItem>
        <NavItem active={section === 'forecast'} icon={Activity} onClick={() => nav('forecast')}>Forecast lab</NavItem>
        <NavItem active={section === 'evaluation'} icon={ClipboardCheck} onClick={() => nav('evaluation')}>Evaluation</NavItem>
        <NavItem active={section === 'chat'} icon={MessageSquareText} onClick={() => nav('chat')}>Ask UdayFlux</NavItem>
      </nav>
      <div className="sidebar-bottom">
        <div className="connection-card"><div className="connection-head"><span className="live-dot"/> SYSTEM ONLINE</div><p>Household meter stream<br/>Sceaux, France · UCI archive</p><div className="connection-foot"><span>Last sync</span><span>Historical · 2010</span></div></div>
        <div className="profile"><div className="profile-avatar">A</div><div><strong>Energy Analyst</strong><small>Local session</small></div><CircleHelp size={16}/></div>
      </div>
    </aside>

    <main className="main-area">
      <header className="topbar"><div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14}/><strong>{section === 'overview' ? 'Overview' : section === 'agents' ? 'Agent studio' : section === 'chat' ? 'Ask UdayFlux' : section === 'forecast' ? 'Forecast lab' : section === 'evaluation' ? 'Evaluation' : 'Anomaly watch'}</strong></div><div className="top-actions"><span className="today-label">{greetingDate}</span><button className="icon-button" title="Refresh data" onClick={() => setRefreshId(id => id + 1)}><RefreshCw size={16}/></button><div className="top-avatar">A</div></div></header>
      <section className="content">
        {error && <div className="error-banner"><CircleHelp size={17}/><span>{error}. Start the Python API with <code>uvicorn api:app --reload --port 8000</code>.</span><button onClick={() => setError('')}>Dismiss</button></div>}
        {section === 'overview' && <Overview dash={dash} loading={loading} days={days} setDays={setDays} nav={nav} prompt={prompt} onAgent={i => { setSelectedAgent(i); nav('agents') }} />}
        {section === 'agents' && <AgentStudio data={agentData} loading={loading || !agentData} selected={selectedAgent} setSelected={setSelectedAgent} />}
        {section === 'anomalies' && <AnomalyPage dash={dash} loading={loading} days={days} setDays={setDays} />}
        {section === 'forecast' && <ForecastPage dash={dash} loading={loading} days={days} setDays={setDays} />}
        {section === 'evaluation' && <EvaluationPage dash={dash} agentData={agentData} loading={loading} days={days} setDays={setDays} />}
        {section === 'chat' && <ChatPage messages={messages} question={question} setQuestion={setQuestion} send={send} busy={chatBusy} mode={chatMode} setMode={setChatMode} prompt={prompt} openEvidence={openEvidence} setOpenEvidence={setOpenEvidence} />}
      </section>
      <footer className="footer"><span><span className="live-dot"/> All systems operational</span><span>Evidence first. Energy smarter.</span><span>UDAYFLUX <b>·</b> v1.0</span></footer>
    </main>
  </div>
}

function PageHeading({ eyebrow, title, detail, right }) { return <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/>{eyebrow}</div><h1>{title}</h1><p>{detail}</p></div>{right}</div> }
function PeriodPicker({ days, setDays }) { return <div className="period-picker">{periods.map(p => <button key={p.days} className={days === p.days ? 'selected' : ''} onClick={() => setDays(p.days)}>{p.label}</button>)}</div> }
function Skeleton({ height = 220 }) { return <div className="skeleton" style={{ height }} /> }
function ChartReveal({ open, onClick, label, children, height = 220 }) {
  return open ? <div className="revealed-chart">{children}<button className="chart-hide-link" onClick={onClick}><ChevronDown size={13}/> Hide visualization</button></div> : <button className="visualization-cover" style={{ minHeight: height }} onClick={onClick}><span className="visualization-icon"><Activity size={19}/></span><strong>{label}</strong><small>Open this visualization when you want to explore the chart.</small><span className="open-visualization">Open visualization <ArrowRight size={14}/></span></button>
}

function Overview({ dash, loading, days, setDays, nav, prompt, onAgent }) {
  const m = dash?.metrics
  const [showDemand, setShowDemand] = useState(false)
  const [showHourly, setShowHourly] = useState(false)
  return <>
    <PageHeading eyebrow="ENERGY INTELLIGENCE / LIVE VIEW" title="Good morning, analyst" detail="Here’s what’s happening across your energy data today." right={<PeriodPicker days={days} setDays={setDays}/>}/>
    <div className="metric-grid">
      <MetricCard label="Average demand" value={loading ? '—' : fmt(m?.mean_kw)} unit="kW" icon={Activity} tone="mint" foot="Selected window average"/>
      <MetricCard label="Peak hour" value={loading ? '—' : fmt(m?.peak_kw)} unit="kW" icon={Zap} tone="amber" foot={m?.peak_time ? when(m.peak_time) : 'Highest hourly mean'}/>
      <MetricCard label="Anomalies flagged" value={loading ? '—' : Number(m?.anomaly_count || 0).toLocaleString()} unit="" icon={ShieldAlert} tone="coral" foot="Robust score ≥ 4.5"/>
      <MetricCard label="Next 24h outlook" value={loading ? '—' : fmt(m?.forecast_mean_kw)} unit="kW" icon={Radio} tone="violet" foot="Gradient boosting model"/>
    </div>

    <div className="overview-grid">
      <section className="panel demand-panel"><div className="panel-heading"><div><div className="eyebrow">LOAD PROFILE</div><h2>Energy demand</h2><p>Hourly active power · kilowatts</p></div><div className="panel-tools">{showDemand&&<div className="legend"><span><i className="legend-dot mint"/>Actual load</span><span><i className="legend-dot coral"/>Anomaly</span></div>}<button className="chart-toggle" onClick={()=>setShowDemand(v=>!v)}>{showDemand?'Hide chart':'Open chart'} <ChevronDown size={13}/></button></div></div>{showDemand&&loading?<Skeleton/>:<ChartReveal open={showDemand} onClick={()=>setShowDemand(v=>!v)} label="Demand trend" height={205}>{dash&&<Chart data={dash.demand} anomalies={dash.anomalies} height={258}/>}</ChartReveal>}{showDemand&&<div className="chart-bottom"><span>Window: {when(dash?.window?.start)} — {when(dash?.window?.end)}</span><button className="text-action" onClick={() => nav('anomalies')}>Inspect patterns <ArrowRight size={14}/></button></div>}</section>
      <section className="panel side-panel"><div className="panel-heading"><div><div className="eyebrow">ASSISTANT</div><h2>Ask UdayFlux</h2><p>Explore your meter data in plain English.</p></div><div className="assistant-orb"><Sparkles size={17}/></div></div><div className="prompt-list"><button onClick={() => prompt('When was the peak demand in this period?')}>When was the peak demand?<ArrowRight size={14}/></button><button onClick={() => prompt('Which hours show unusual energy consumption?')}>Spot unusual consumption<ArrowRight size={14}/></button><button onClick={() => prompt('What does the demand forecast show for tomorrow?')}>Forecast demand tomorrow<ArrowRight size={14}/></button></div><button className="primary-button full" onClick={() => nav('chat')}><MessageSquareText size={16}/> Open energy copilot</button><div className="privacy-note"><span className="tiny-lock">●</span> Raw meter history stays on this machine.</div></section>
    </div>

    <div className="lower-grid">
      <section className="panel chart-small-panel"><div className="panel-heading compact"><div><div className="eyebrow">DAILY RHYTHM</div><h2>Average load by hour</h2></div><button className="chart-toggle" onClick={()=>setShowHourly(v=>!v)}>{showHourly?'Hide chart':'Open chart'} <ChevronDown size={13}/></button></div>{showHourly&&loading?<Skeleton height={155}/> : <ChartReveal open={showHourly} onClick={()=>setShowHourly(v=>!v)} label="Hourly load profile" height={155}>{dash&&<MiniBars data={dash.hourly_profile}/>}</ChartReveal>}</section>
      <section className="panel fleet-panel"><div className="panel-heading compact"><div><div className="eyebrow">SPECIALIST WORKFLOW</div><h2>Agent fleet <span className="count-pill">05</span></h2></div><button className="more-button" onClick={() => nav('agents')}>Open studio <ArrowRight size={14}/></button></div><div className="fleet-strip">{agentMeta.map((a,i) => <button key={a.name} className={`fleet-agent ${a.tone}`} onClick={() => onAgent(i)} title={a.name}><span className="fleet-icon"><a.icon size={15}/></span><i className="agent-ready"/><small>{a.short}</small></button>)}</div><div className="fleet-status"><span className="live-dot"/> All specialists ready <span className="status-divider"/> <span>4 evidence handoffs</span></div></section>
    </div>
    <div className="source-note"><CircleHelp size={14}/> Single household dataset from Sceaux, France · Use as a load-shape example, not a regional grid signal.</div>
  </>
}

function AgentStudio({ data, loading, selected, setSelected }) {
  const agent = agentMeta[selected]
  const payload = data?.agents?.[selected]
  return <>
    <PageHeading eyebrow="MULTI-AGENT INTELLIGENCE" title="Agent studio" detail="Five specialist agents. One evidence-backed operational picture." right={<div className="system-pill"><span className="live-dot"/> Workflow active</div>}/>
    <section className="agent-flow panel"><div className="flow-title"><div><span className="eyebrow">LANGGRAPH STATEGRAPH</span><h2>Parallel analysis, joined insight</h2></div><span className="flow-caption"><Radio size={14}/> 3 parallel nodes · 2 handoff nodes</span></div><div className="langgraph-diagram"><div className="graph-entry"><small>START</small><b>Question +<br/>load window</b><span>Shared graph state</span></div><ArrowRight className="graph-arrow" size={17}/><div className="parallel-group"><small className="graph-group-label">PARALLEL ANALYTICS</small><div className="parallel-nodes">{agentMeta.slice(0,3).map((a,i)=><button key={a.name} className={`graph-agent ${a.tone} ${selected===i?'is-current':''}`} onClick={()=>setSelected(i)}><span className="flow-node-icon"><a.icon size={16}/></span><span><b>{a.short}</b><small>Runs concurrently</small></span></button>)}</div></div><ArrowRight className="graph-arrow join-arrow" size={17}/><div className="serial-group">{agentMeta.slice(3).map((a,j)=>{const i=j+3;return <button key={a.name} className={`graph-agent ${a.tone} ${selected===i?'is-current':''}`} onClick={()=>setSelected(i)}><span className="flow-node-icon"><a.icon size={16}/></span><span><b>{a.short}</b><small>{i===3?'Joins specialist findings':'Uses combined evidence'}</small></span></button>})}</div></div><div className="flow-caption bottom"><span className="live-dot"/> Parallel specialists update separate state keys; Insight joins their results before Decision Support runs.</div></section>
    <div className="agent-layout"><section className="agent-list panel"><div className="panel-heading compact"><div><div className="eyebrow">YOUR SPECIALISTS</div><h2>Agent roster</h2></div><span className="count-pill">5 / 5</span></div>{agentMeta.map((a,i) => <button key={a.name} className={`agent-row ${selected===i?'selected':''} ${a.tone}`} onClick={() => setSelected(i)}><span className="agent-icon"><a.icon size={17}/></span><span className="agent-row-text"><strong>{a.name}</strong><small>{a.short}</small></span><span className="row-ready"><i/> Ready</span><ChevronRight size={15}/></button>)}<div className="a2a-foot"><div className="a2a-icon"><Command size={15}/></div><span><b>{data?.orchestrator || 'LangGraph StateGraph'}</b><small>Parallel nodes · evidence handoffs · trace IDs</small></span></div></section>
      <section className={`agent-detail panel agent-${agent.tone}`}><div className="agent-detail-top"><div className="agent-detail-icon"><agent.icon size={23}/></div><div><div className="eyebrow">SPECIALIST {String(selected+1).padStart(2,'0')} / 05</div><h2>{agent.name}</h2></div><span className="complete-pill"><span/> {loading?'Running':'Complete'}</span></div><p className="agent-description">{agent.role}</p>{loading || !payload ? <Skeleton height={200}/> : <><div className="agent-result"><div className="result-head"><span>RESULT SUMMARY</span><span className="result-time"><Clock3 size={12}/> Just now</span></div><p>{payload.summary}</p><button className="evidence-toggle" onClick={() => setSelected(selected)}><span>Evidence packet</span><ChevronDown size={15}/></button><pre className="evidence-json">{JSON.stringify(payload.evidence, null, 2)}</pre></div>{selected===4 && data?.recommendations && <div className="recommendation-list"><span className="eyebrow">SUGGESTED ACTIONS</span>{data.recommendations.map((r,i)=><div key={i}><span>{String(i+1).padStart(2,'0')}</span><p>{r}</p></div>)}</div>}</>}
      </section></div>
    <section className="panel handoff-panel"><div className="panel-heading compact"><div><div className="eyebrow">TRACEABILITY</div><h2>Recent handoffs</h2></div><span className="count-pill">{data?.handoffs?.length || 4} messages</span></div><div className="handoff-table">{data?.handoffs?.map((h,i)=><div className="handoff-row" key={h.message_id}><span className="handoff-index">0{i+1}</span><span><b>{h.sender}</b><small>{h.kind.replaceAll('_',' ')}</small></span><ArrowRight size={15}/><span><b>{h.recipient}</b><small>Evidence attached</small></span><code>{h.message_id}</code></div>) || <Skeleton height={110}/>}</div></section>
  </>
}

function AnomalyPage({ dash, loading, days, setDays }) {
  const rows = dash?.anomalies || []
  const [showChart, setShowChart] = useState(false)
  return <><PageHeading eyebrow="DETECTION / PATTERN WATCH" title="Anomaly watch" detail="Unusual demand candidates with the evidence to inspect each one." right={<PeriodPicker days={days} setDays={setDays}/>}/><div className="metric-grid anomaly-metrics"><MetricCard label="Flagged hours" value={loading?'—':dash?.metrics?.anomaly_count ?? 0} unit="" icon={ShieldAlert} tone="coral" foot="Robust score ≥ 4.5"/><MetricCard label="Detection method" value="MAD" unit="" icon={Activity} tone="violet" foot="Rolling median baseline"/><MetricCard label="Window mean" value={loading?'—':fmt(dash?.metrics?.mean_kw)} unit="kW" icon={Gauge} tone="mint" foot="Selected period"/><MetricCard label="Review queue" value={loading?'—':rows.length} unit="events" icon={CircleHelp} tone="amber" foot="Top evidence records"/></div><section className="panel demand-panel"><div className="panel-heading"><div><div className="eyebrow">LOAD + EVENT OVERLAY</div><h2>Flagged demand behavior</h2><p>Coral markers show the highest-scoring outliers.</p></div><div className="panel-tools">{showChart&&<div className="score-key"><i/> Anomaly event</div>}<button className="chart-toggle" onClick={()=>setShowChart(v=>!v)}>{showChart?'Hide chart':'Open chart'} <ChevronDown size={13}/></button></div></div>{showChart&&loading?<Skeleton/>:<ChartReveal open={showChart} onClick={()=>setShowChart(v=>!v)} label="Anomaly overlay" height={215}>{dash&&<Chart data={dash.demand} anomalies={rows} height={290}/>}</ChartReveal>}</section><section className="panel table-panel"><div className="panel-heading compact"><div><div className="eyebrow">EVIDENCE LOG</div><h2>Events to review</h2></div><span className="count-pill">{dash?.metrics?.anomaly_count || 0} total</span></div><div className="table-scroll"><table><thead><tr><th>TIME</th><th>OBSERVED</th><th>BASELINE</th><th>DEVIATION</th><th>ROBUST SCORE</th><th>SEVERITY</th></tr></thead><tbody>{loading?<tr><td colSpan="6">Loading evidence…</td></tr>:rows.length?rows.map((r,i)=><tr key={i}><td>{when(r.timestamp)}</td><td>{fmt(r.observed_kw)} kW</td><td>{fmt(r.baseline_kw)} kW</td><td className={Number(r.deviation_kw)>0?'positive':'negative'}>{Number(r.deviation_kw)>0?'+':''}{fmt(r.deviation_kw)} kW</td><td><b>{fmt(r.robust_score,1)}</b></td><td><span className={`severity ${Number(r.robust_score)>8?'high':'medium'}`}>{Number(r.robust_score)>8?'High':'Review'}</span></td></tr>):<tr><td colSpan="6">No outlier records in this selected window.</td></tr>}</tbody></table></div><div className="table-foot">Unsupervised flags are candidates for analyst review. The dataset has no labeled anomalies for precision/recall scoring.</div></section></>
}

function ForecastPage({ dash, loading, days, setDays }) {
  const metrics = dash?.forecast_metrics || {}
  const [showForecast, setShowForecast] = useState(false)
  const [showHourly, setShowHourly] = useState(false)
  return <><PageHeading eyebrow="PREDICTIVE ANALYTICS / FORECAST LAB" title="Demand forecast" detail="A 24-hour outlook, evaluated against a same-hour-previous-day baseline." right={<PeriodPicker days={days} setDays={setDays}/>}/><div className="forecast-banner"><div className="forecast-orb"><Radio size={20}/></div><div><span className="eyebrow">NEXT 24 HOURS</span><strong>{loading?'—':fmt(dash?.metrics?.forecast_mean_kw)} <small>kW average</small></strong><p>Histogram gradient boosting · hourly resolution</p></div><div className="forecast-confidence"><span>MODEL STATUS</span><b><i/> Evaluated</b><small>Chronological holdout · no shuffle</small></div></div><section className="panel demand-panel forecast-chart-panel"><div className="panel-heading"><div><div className="eyebrow">SHORT-HORIZON LOAD PREDICTION</div><h2>History meets forecast</h2><p>Solid line is observed load; dashed violet line is projected demand.</p></div><div className="panel-tools">{showForecast&&<div className="legend"><span><i className="legend-dot mint"/>Observed</span><span><i className="legend-dash"/>Forecast</span></div>}<button className="chart-toggle" onClick={()=>setShowForecast(v=>!v)}>{showForecast?'Hide chart':'Open chart'} <ChevronDown size={13}/></button></div></div>{showForecast&&loading?<Skeleton/>:<ChartReveal open={showForecast} onClick={()=>setShowForecast(v=>!v)} label="24-hour load forecast" height={225}>{dash&&<Chart data={dash.demand?.slice(-336)} forecast={dash.forecast} height={310}/>}</ChartReveal>}</section><div className="eval-grid"><MetricCard label="Holdout MAE" value={loading?'—':fmt(metrics.mae,3)} unit="kW" icon={Activity} tone="mint" foot={`${metrics.holdout_hours || '—'} validation hours`}/><MetricCard label="Holdout RMSE" value={loading?'—':fmt(metrics.rmse,3)} unit="kW" icon={Gauge} tone="violet" foot="Chronological test window"/><MetricCard label="Holdout MAPE" value={loading?'—':fmt(metrics.mape,2)} unit="%" icon={ArrowUpRight} tone="amber" foot="Guarded for zero readings"/><MetricCard label="Naive baseline MAE" value={loading?'—':fmt(metrics.baseline_mae,3)} unit="kW" icon={Clock3} tone="blue" foot="Previous-day same hour"/></div><section className="panel forecast-list"><div className="panel-heading compact"><div><div className="eyebrow">HOURLY PROJECTION</div><h2>Tomorrow, hour by hour</h2></div><button className="chart-toggle" onClick={()=>setShowHourly(v=>!v)}>{showHourly?'Hide chart':'Open chart'} <ChevronDown size={13}/></button></div><ChartReveal open={showHourly} onClick={()=>setShowHourly(v=>!v)} label="Hourly forecast detail" height={160}>{dash&&<div className="forecast-points">{(dash.forecast||[]).map((f,i)=><div className="forecast-point" key={f.time}><small>{new Date(f.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</small><span style={{height:`${25+Math.max(0,Math.min(75,(f.value/Math.max(...(dash.forecast.map(x=>x.value))||1)*75)))}%`}}/><b>{fmt(f.value)}</b><em>{i===0?'NOW + 1H':`${i+1}H`}</em></div>)}</div>}</ChartReveal></section></>
}

function EvaluationPage({ dash, agentData, loading, days, setDays }) {
  const metrics = dash?.forecast_metrics || {}
  const quality = dash?.data_quality || {}
  const baselineSkill = Number.isFinite(Number(metrics.mae)) && Number(metrics.baseline_mae) > 0
    ? (Number(metrics.baseline_mae) - Number(metrics.mae)) / Number(metrics.baseline_mae) * 100
    : null
  const qualityRows = [
    ['Input observations', quality.rows_input],
    ['Clean timestamped rows', quality.rows_clean],
    ['Invalid timestamps removed', quality.invalid_timestamps],
    ['Duplicate timestamps removed', quality.duplicate_timestamps_removed],
    ['Active power missing before interpolation', quality.missing_active_power_before_interpolation],
    ['Active power still missing after interpolation', quality.missing_active_power_after_interpolation],
  ]
  return <>
    <PageHeading eyebrow="EVALUATION / QUALITY & VALIDATION" title="Evaluation center" detail="Forecast scores, data checks, and honest coverage for the parts without labels." right={<PeriodPicker days={days} setDays={setDays}/>}/>
    <div className="eval-grid evaluation-score-grid">
      <MetricCard label="Forecast MAE" value={loading?'—':fmt(metrics.mae,3)} unit="kW" icon={Activity} tone="mint" foot={`${metrics.holdout_hours || '—'} chronological holdout hours`}/>
      <MetricCard label="Forecast RMSE" value={loading?'—':fmt(metrics.rmse,3)} unit="kW" icon={Gauge} tone="violet" foot="Lower is better"/>
      <MetricCard label="Forecast MAPE" value={loading?'—':fmt(metrics.mape,2)} unit="%" icon={ArrowUpRight} tone="blue" foot="Zero readings excluded"/>
      <MetricCard label="MAE vs seasonal naive" value={loading?'—':baselineSkill===null?'—':`${baselineSkill>=0?'+':''}${baselineSkill.toFixed(1)}`} unit="%" icon={ClipboardCheck} tone="amber" foot={baselineSkill===null?'Baseline comparison unavailable':baselineSkill>=0?'Lower error than baseline':'Higher error than baseline'}/>
    </div>
    <div className="evaluation-grid">
      <section className="panel evaluation-panel"><div className="panel-heading compact"><div><div className="eyebrow">FORECAST VALIDATION</div><h2>Chronological holdout</h2></div><span className="evaluation-tag scored">Scored</span></div><p className="evaluation-copy">The final portion of the selected hourly series is held out in time order. The fitted model is compared with a previous-day same-hour seasonal-naive forecast.</p><div className="validation-facts"><div><span>MODEL</span><b>HistGradientBoostingRegressor</b></div><div><span>BASELINE</span><b>Previous day · same hour</b></div><div><span>HOLDOUT HOURS</span><b>{metrics.holdout_hours ?? '—'}</b></div><div><span>VALIDATION WINDOW</span><b>{metrics.holdout_start?`${when(metrics.holdout_start)} — ${when(metrics.holdout_end)}`:'—'}</b></div><div><span>BASELINE MAE</span><b>{loading?'—':`${fmt(metrics.baseline_mae,3)} kW`}</b></div><div><span>MODEL MAE</span><b>{loading?'—':`${fmt(metrics.mae,3)} kW`}</b></div></div></section>
      <section className="panel evaluation-panel"><div className="panel-heading compact"><div><div className="eyebrow">DETECTION & LANGUAGE QUALITY</div><h2>Coverage, not made-up scores</h2></div><span className="evaluation-tag review">Needs labels</span></div><div className="coverage-row"><span className="coverage-icon amber"><ShieldAlert size={16}/></span><div><b>Anomaly effectiveness</b><small>{Number(dash?.metrics?.anomaly_count || 0).toLocaleString()} hours flagged at robust score ≥ 4.5. The source has no labeled anomalies.</small></div><strong>Not scored</strong></div><div className="coverage-row"><span className="coverage-icon violet"><MessageSquareText size={16}/></span><div><b>Natural-language accuracy</b><small>Tool choices and returned evidence are inspectable. A scored accuracy rate requires an annotated question set.</small></div><strong>Not scored</strong></div><div className="coverage-row"><span className="coverage-icon blue"><Sparkles size={16}/></span><div><b>Insight groundedness</b><small>Answers expose tool outputs in the evidence panel; human review is still needed to score generated explanations.</small></div><strong>Review evidence</strong></div><div className="coverage-row"><span className="coverage-icon cyan"><Cpu size={16}/></span><div><b>LangGraph workflow</b><small>{agentData?.orchestrator || 'LangGraph StateGraph'} · parallel analysis, anomaly, and forecast nodes join before decision support.</small></div><strong>{agentData?`${agentData.handoffs?.length || 0} handoffs`:'Loading trace'}</strong></div></section>
    </div>
    <section className="panel data-quality-panel"><div className="panel-heading compact"><div><div className="eyebrow">DATA PREPARATION AUDIT</div><h2>Source quality checks</h2></div><span className="evaluation-tag scored">Inspectible</span></div><p className="evaluation-copy">Counts come from the loaded UCI source. Short gaps are interpolated for modeling; long missing runs remain missing.</p><div className="quality-grid">{qualityRows.map(([label,value])=><div className="quality-item" key={label}><span>{label}</span><b>{loading?'—':Number.isFinite(Number(value))?Number(value).toLocaleString():'—'}</b></div>)}</div><div className="quality-period"><Clock3 size={14}/><span>Data range</span><b>{quality.time_range_start?`${when(quality.time_range_start)} — ${when(quality.time_range_end)}`:'Loading source range…'}</b></div></section>
    <div className="evaluation-footnote"><CircleHelp size={14}/><span>Forecast metrics describe the selected window. The anomaly and LLM quality measures are marked unscored until suitable labeled reference data is available.</span></div>
  </>
}

function ChatPage({ messages, question, setQuestion, send, busy, mode, setMode, prompt, openEvidence, setOpenEvidence }) {
  const suggestions = ['When was the peak demand?', 'Which hours look unusual?', 'Forecast the next 24 hours', 'What operational insights can you derive?']
  return <><PageHeading eyebrow="NATURAL LANGUAGE / EVIDENCE GROUNDED" title="Ask UdayFlux" detail="Choose local analytics or OpenRouter for each answer." right={<div className="system-pill"><Sparkles size={14}/> Tool-using AI</div>}/><div className="chat-layout"><aside className="chat-context panel"><div className="chat-orb"><div><Zap size={23} fill="currentColor"/></div><span className="orbit orbit-a"/><span className="orbit orbit-b"/></div><div className="context-title">Your energy<br/>copilot<span>.</span></div><p>Choose the response engine. OpenRouter automatically falls back to local analytics if unavailable.</p><div className="context-divider"/><div className="context-stat"><span>AVAILABLE TOOLS</span><b>04</b><small>Load · anomalies · forecast · agent team</small></div><div className="context-stat"><span>ACTIVE AGENTS</span><b>05</b><small>Specialists ready for handoff</small></div><div className="context-safety"><ShieldAlert size={15}/><span>Explanations use measured evidence. The model won’t claim a cause the data can’t prove.</span></div></aside>
    <section className="chat-window panel"><div className="chat-window-head"><div className="chat-assistant-avatar"><Sparkles size={17}/><i/></div><div><b>UdayFlux assistant</b><small><span className="live-dot"/> Ready to analyze</small></div><button className="icon-button" onClick={() => { }} title="Conversation options"><ChevronDown size={15}/></button></div><div className="messages-area">{messages.map((m,i)=><div className={`message-row ${m.role}`} key={i}><div className={`message-avatar ${m.role}`}>{m.role==='assistant'?<Sparkles size={14}/>:<span>A</span>}</div><div className="message-content"><div className="message-bubble">{m.text}</div>{m.role==='assistant'&&m.evidence&&<div className="answer-meta"><span className="provider-chip"><Bot size={12}/>{m.provider||'Local analytics'}{m.model?` · ${m.model}`:''}</span>{m.sources?.length>0&&<><span className="source-label">Tools: {m.sources.join(', ')}</span><button className="evidence-button" onClick={()=>setOpenEvidence(openEvidence===i?null:i)}>{openEvidence===i?'Hide':'View'} evidence <ChevronDown size={12}/></button></>}{openEvidence===i&&<pre className="chat-evidence">{JSON.stringify(m.evidence,null,2)}</pre>}</div>}{m.note&&<small className="fallback-note">{m.note}</small>}</div></div>)}{busy&&<div className="message-row assistant"><div className="message-avatar assistant"><Sparkles size={14}/></div><div className="typing-bubble"><span/><span/><span/><small>Checking the right energy tools…</small></div></div>}</div><div className="suggestions">{suggestions.map((s,i)=><button key={s} onClick={()=>send(s)}><span>{['⌁','◌','↗','✳'][i]}</span>{s}</button>)}</div><form className="chat-composer" onSubmit={e=>{e.preventDefault();send()}}><textarea value={question} onChange={e=>setQuestion(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}} placeholder="Ask anything about your energy data…" rows={1}/><button className="send-button" type="submit" disabled={!question.trim()||busy}><ArrowRight size={17}/></button><label className="provider-choice"><span>Answer with</span><select value={mode} onChange={e=>setMode(e.target.value)} aria-label="Choose answer provider"><option value="local">Local analytics</option><option value="openrouter">OpenRouter · auto fallback to local</option></select></label><div className="composer-hint"><span><Command size={11}/> Enter to send</span><span><ShieldAlert size={11}/> Evidence-grounded responses</span></div></form></section></div></>
}

export default App
